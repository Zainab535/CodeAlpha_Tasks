// Example quotes array (or fetch from API)
const quotes = [
    "The best way to predict the future is to invent it. - Alan Kay",
    "Life is 10% what happens to us and 90% how we react to it. - Charles R. Swindoll",
    "Your time is limited, so don’t waste it living someone else’s life. - Steve Jobs",
    "You only live once, but if you do it right, once is enough. - Mae West"
  ];
    const quoteElement = document.getElementById("quote");
  const generateButton = document.getElementById("generate");
  const shareButton = document.getElementById("share");
  
  // Function to generate a random quote
  function generateQuote() {
    const randomIndex = Math.floor(Math.random() * quotes.length);
    quoteElement.textContent = quotes[randomIndex];
  }
  
  // Function to share the quote on Twitter
  function shareQuote() {
    const quote = quoteElement.textContent;
    const twitterUrl = `https://twitter.com/intent/tweet?text=${encodeURIComponent(quote)}`;
    window.open(twitterUrl, "_blank");
  }
  
  // Event listeners
  generateButton.addEventListener("click", generateQuote);
  shareButton.addEventListener("click", shareQuote);

  //Here we are making it dynamic (Its optional)
  async function fetchQuotes() {
    const response = await fetch("https://type.fit/api/quotes");
    const data = await response.json();
    return data.map(quote => `${quote.text} - ${quote.author || "Unknown"}`);
  }
  
  // Replace static quotes with dynamic fetching
  let quote = [];
  fetchQuotes().then(fetchedQuotes => {
    quotes = fetchedQuotes;
    generateQuote(); // Show the first quote
  });
  