const express = require("express");
const router = express.Router();

let workouts = []; // Temporary storage

// Get all workouts
router.get("/", (req, res) => {
    res.json(workouts);
});

// Add a new workout
router.post("/", (req, res) => {
    const { name, duration, calories } = req.body;

    if (!name || !duration || !calories) {
        return res.status(400).json({ message: "All fields (name, duration, calories) are required!" });
    }

    const newWorkout = { name, duration, calories };
    workouts.push(newWorkout);

    res.status(201).json({
        message: "Workout added successfully!",
        workout: newWorkout
    });
});

// Update a workout
router.put("/:name", (req, res) => {
    const { name } = req.params;
    const { duration, calories } = req.body;

    const workout = workouts.find(w => w.name === name);
    if (!workout) {
        return res.status(404).json({ message: "Workout not found!" });
    }

    // Update properties if provided
    if (duration) workout.duration = duration;
    if (calories) workout.calories = calories;

    res.json({ message: "Workout updated successfully!", workout });
});

// Delete a workout
router.delete("/:name", (req, res) => {
    const { name } = req.params;

    const initialLength = workouts.length;
    workouts = workouts.filter(w => w.name !== name);

    if (workouts.length === initialLength) {
        return res.status(404).json({ message: "Workout not found!" });
    }

    res.json({ message: "Workout deleted successfully!" });
});

module.exports = router;
