const express = require("express"); // Import Express
const cors = require('cors');  // CORS ko import kiya
// const mongoose = require('mongoose');

const app = express(); // Create an Express application
app.use(cors());  // CORS enable kar diya

app.use(express.json()); // Middleware to parse JSON requests

// for permanent data storage we use mongoDb
// app.use(express.json());
// app.use(cors());

// // MongoDB connection
// mongoose.connect('mongodb://localhost:27017/fitnessTracker', { 
//   useNewUrlParser: true, 
//   useUnifiedTopology: true 
// })
// .then(() => console.log('MongoDB connected...'))
// .catch(err => console.log('MongoDB connection error:', err));

// // Workout Schema (Define MongoDB Model)
// const workoutSchema = new mongoose.Schema({
//   name: String,
//   duration: Number,
//   calories: Number
// });
// // MongoDB Model for Workouts
// const Workout = mongoose.model('Workout', workoutSchema);

// Import routes
const workoutRoutes = require("./workouts"); // Corrected path and variable name
const goalRoutes = require("./goals"); // Corrected path and variable name

// Use routes
app.use("/api/workouts", workoutRoutes); // Corrected to workoutRoutes
app.use("/api/goals", goalRoutes); // Corrected to goalRoutes

// Default route
app.get("/", (req, res) => {
    res.send("Hello, Fitness Tracker!");
});

// Handle invalid routes
app.use((req, res) => {
    res.status(404).json({ message: "Route not found!" });
});

// Start the server
app.listen(4000, () => {
    console.log("Server is running on http://localhost:4000");
});
