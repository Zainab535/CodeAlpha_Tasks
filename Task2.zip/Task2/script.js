// Dummy Data for Progress
let workouts = [
    { date: "2025-01-01", duration: 30 },
    { date: "2025-01-02", duration: 45 },
  ];
  
  document.getElementById("workout-form").addEventListener("submit", (e) => {
    e.preventDefault();
    const exercise = document.getElementById("exercise").value;
    const duration = parseInt(document.getElementById("duration-input").value);
  
    // Add to summary
    const currentCalories = parseInt(document.getElementById("calories").textContent);
    document.getElementById("calories").textContent = currentCalories + duration * 5; // Dummy calorie logic
  
    const currentDuration = parseInt(document.getElementById("duration").textContent);
    document.getElementById("duration").textContent = currentDuration + duration;
  
    // Clear form
    document.getElementById("exercise").value = "";
    document.getElementById("duration-input").value = "";
  
    // Update Progress
    workouts.push({ date: new Date().toISOString().split("T")[0], duration });
    updateProgress();
  });
  
  function updateProgress() {
    // Use Chart.js or console.log(workouts) to view data.
    console.log(workouts);
  }
  