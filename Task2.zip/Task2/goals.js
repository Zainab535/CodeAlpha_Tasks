const express = require("express");
const router = express.Router();

let goals = []; // Temporary storage

// Get all goals
router.get("/", (req, res) => {
    res.json(goals);
});

// Add a new goal
router.post("/", (req, res) => {
    const { goal, completed } = req.body;

    if (!goal) {
        return res.status(400).json({ message: "Goal field is required!" });
    }

    const newGoal = { goal, completed: completed || false };
    goals.push(newGoal);

    res.status(201).json({
        message: "Goal added successfully!",
        goal: newGoal
    });
});

// Update a goal
router.put("/:goal", (req, res) => {
    const { goal } = req.params;
    const { completed } = req.body;

    const foundGoal = goals.find(g => g.goal === goal);
    if (!foundGoal) {
        return res.status(404).json({ message: "Goal not found!" });
    }

    // Update properties if provided
    if (typeof completed !== "undefined") foundGoal.completed = completed;

    res.json({ message: "Goal updated successfully!", goal: foundGoal });
});

// Delete a goal
router.delete("/:goal", (req, res) => {
    const { goal } = req.params;

    const initialLength = goals.length;
    goals = goals.filter(g => g.goal !== goal);

    if (goals.length === initialLength) {
        return res.status(404).json({ message: "Goal not found!" });
    }

    res.json({ message: "Goal deleted successfully!" });
});

module.exports = router;
